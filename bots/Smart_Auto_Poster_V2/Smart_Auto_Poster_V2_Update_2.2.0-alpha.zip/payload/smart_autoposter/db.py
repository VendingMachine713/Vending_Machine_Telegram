from __future__ import annotations

import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path

SCHEMA = r'''
PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS meta (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS accounts (
    account_key TEXT PRIMARY KEY,
    session_name TEXT NOT NULL,
    enabled INTEGER NOT NULL DEFAULT 1,
    authorized INTEGER,
    identity TEXT,
    cooldown_until TEXT,
    consecutive_failures INTEGER NOT NULL DEFAULT 0,
    last_error TEXT,
    last_success_at TEXT,
    last_failure_at TEXT,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS destinations (
    group_id INTEGER PRIMARY KEY,
    group_name TEXT NOT NULL,
    chat_type TEXT,
    username TEXT,
    forum INTEGER NOT NULL DEFAULT 0,
    topic_id INTEGER,
    primary_access INTEGER NOT NULL DEFAULT 0,
    secondary_access INTEGER NOT NULL DEFAULT 0,
    preferred_account TEXT NOT NULL DEFAULT 'primary',
    mode TEXT NOT NULL DEFAULT 'review',
    enabled INTEGER NOT NULL DEFAULT 0,
    needs_review INTEGER NOT NULL DEFAULT 1,
    min_interval_seconds INTEGER NOT NULL DEFAULT 0,
    quiet_start TEXT,
    quiet_end TEXT,
    last_post_at TEXT,
    next_eligible_at TEXT,
    consecutive_failures INTEGER NOT NULL DEFAULT 0,
    quarantine_until TEXT,
    notes TEXT,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS destination_tags (
    group_id INTEGER NOT NULL REFERENCES destinations(group_id) ON DELETE CASCADE,
    tag TEXT NOT NULL,
    PRIMARY KEY (group_id, tag)
);

CREATE TABLE IF NOT EXISTS content (
    content_id TEXT PRIMARY KEY,
    caption TEXT NOT NULL DEFAULT '',
    media_json TEXT NOT NULL DEFAULT '[]',
    enabled INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS campaigns (
    campaign_id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    content_id TEXT NOT NULL REFERENCES content(content_id),
    enabled INTEGER NOT NULL DEFAULT 0,
    priority INTEGER NOT NULL DEFAULT 50,
    target_tags TEXT NOT NULL DEFAULT '',
    start_at TEXT,
    end_at TEXT,
    min_destination_interval_seconds INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS campaign_schedules (
    campaign_id TEXT PRIMARY KEY REFERENCES campaigns(campaign_id) ON DELETE CASCADE,
    mode TEXT NOT NULL DEFAULT 'manual',
    interval_seconds INTEGER,
    daily_times_json TEXT NOT NULL DEFAULT '[]',
    days_json TEXT NOT NULL DEFAULT '[]',
    timezone TEXT NOT NULL DEFAULT 'Australia/Adelaide',
    next_run_at TEXT,
    last_run_at TEXT,
    jitter_seconds INTEGER NOT NULL DEFAULT 0,
    enabled INTEGER NOT NULL DEFAULT 0,
    updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_schedule_due ON campaign_schedules(enabled, next_run_at);

CREATE TABLE IF NOT EXISTS queue (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    job_key TEXT NOT NULL UNIQUE,
    run_key TEXT,
    campaign_id TEXT NOT NULL REFERENCES campaigns(campaign_id),
    group_id INTEGER NOT NULL REFERENCES destinations(group_id),
    account_key TEXT,
    due_at TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    attempts INTEGER NOT NULL DEFAULT 0,
    max_attempts INTEGER NOT NULL DEFAULT 4,
    last_error TEXT,
    telegram_message_ids TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_queue_due ON queue(status, due_at);
CREATE INDEX IF NOT EXISTS idx_queue_campaign ON queue(campaign_id, status);

CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at TEXT NOT NULL,
    severity TEXT NOT NULL,
    event_type TEXT NOT NULL,
    account_key TEXT,
    group_id INTEGER,
    campaign_id TEXT,
    message TEXT NOT NULL,
    details TEXT
);
CREATE INDEX IF NOT EXISTS idx_events_created_type ON events(created_at, event_type);
'''


def utcnow() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class Database:
    def __init__(self, path: Path):
        self.path = Path(path)

    @contextmanager
    def connect(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        con = sqlite3.connect(self.path, timeout=30)
        con.row_factory = sqlite3.Row
        try:
            con.execute("PRAGMA foreign_keys=ON")
            con.execute("PRAGMA busy_timeout=30000")
            yield con
            con.commit()
        finally:
            con.close()

    @staticmethod
    def _columns(con, table: str) -> set[str]:
        return {r[1] for r in con.execute(f"PRAGMA table_info({table})").fetchall()}

    def _migrate(self, con):
        # Additive migrations keep existing V2 databases usable in-place.
        additions = {
            "accounts": {
                "last_success_at": "TEXT",
                "last_failure_at": "TEXT",
            },
            "queue": {
                "run_key": "TEXT",
            },
        }
        for table, columns in additions.items():
            existing = self._columns(con, table)
            for name, sql_type in columns.items():
                if name not in existing:
                    con.execute(f"ALTER TABLE {table} ADD COLUMN {name} {sql_type}")

    def init(self):
        with self.connect() as con:
            con.executescript(SCHEMA)
            self._migrate(con)
            con.execute("INSERT OR REPLACE INTO meta(key,value) VALUES('schema_version','3')")


    def backup_to(self, destination: Path):
        """Create a consistent online SQLite backup, including WAL-resident data."""
        destination = Path(destination)
        destination.parent.mkdir(parents=True, exist_ok=True)
        src = sqlite3.connect(self.path, timeout=30)
        dst = sqlite3.connect(destination)
        try:
            src.execute("PRAGMA busy_timeout=30000")
            src.backup(dst)
        finally:
            dst.close()
            src.close()
        return destination

    def event(self, severity, event_type, message, *, account_key=None, group_id=None, campaign_id=None, details=None):
        with self.connect() as con:
            con.execute(
                "INSERT INTO events(created_at,severity,event_type,account_key,group_id,campaign_id,message,details) VALUES(?,?,?,?,?,?,?,?)",
                (utcnow(), severity, event_type, account_key, group_id, campaign_id, message, details),
            )
