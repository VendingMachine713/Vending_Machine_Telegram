from __future__ import annotations

import argparse
import asyncio
import csv
import json
import shutil
from pathlib import Path

from .core import create_campaign, create_content, enqueue_campaign, validate
from .db import Database, utcnow
from .importer import import_config
from .scheduler import Scheduler, configure_daily, configure_interval, disable_schedule
from .settings import Settings
from .runtime_lock import RuntimeLock
from .safety import SafetyController
from .time_rules import parse_hhmm


def db_for(settings: Settings):
    settings.ensure_dirs()
    db = Database(settings.database_path)
    db.init()
    return db


def _backup_file(src: Path, dst_dir: Path, prefix: str | None = None):
    if not src.exists():
        return None
    dst_dir.mkdir(parents=True, exist_ok=True)
    stamp = utcnow().replace(":", "").replace("+00:00", "Z")
    name = f"{prefix or src.stem}_{stamp}{src.suffix}"
    dst = dst_dir / name
    shutil.copy2(src, dst)
    return dst


def cmd_init(args):
    s = Settings.load(False)
    s.ensure_dirs()
    db = db_for(s)
    print(f"[OK] Database ready: {db.path}")
    print(f"[OK] Runtime folders ready under: {Path.cwd()}")


def cmd_import(args):
    s = Settings.load(False); db = db_for(s)
    src = Path(args.csv or s.config_csv)
    stamp = utcnow().replace(":", "").replace("+00:00", "Z")
    backup = s.backup_dir / f"smart_autoposter_before_import_{stamp}.sqlite3"
    db.backup_to(backup)
    result = import_config(db, src)
    print(f"[BACKUP] {backup}")
    print(f"[OK] Imported {src}: added={result['added']} updated={result['updated']}")


def cmd_validate(args):
    s = Settings.load(False); db = db_for(s)
    problems = validate(db)
    if problems:
        print("[FAIL] Pre-flight problems:")
        for x in problems:
            print(" -", x)
        raise SystemExit(2)
    print("[OK] Local pre-flight validation passed")


def cmd_add_content(args):
    s = Settings.load(False); db = db_for(s)
    caption = Path(args.caption_file).read_text(encoding="utf-8") if args.caption_file else (args.caption or "")
    create_content(db, args.content_id, caption, args.media or [])
    print(f"[OK] Content saved: {args.content_id}")


def cmd_contents(args):
    s = Settings.load(False); db = db_for(s)
    with db.connect() as con:
        rows = con.execute("SELECT content_id,enabled,caption,media_json,updated_at FROM content ORDER BY content_id").fetchall()
    if not rows:
        print("No content items."); return
    print(f"{'CONTENT':24} {'ON':3} {'MEDIA':5} CAPTION")
    print("-" * 80)
    for r in rows:
        try: count = len(json.loads(r["media_json"] or "[]"))
        except Exception: count = -1
        preview = (r["caption"] or "").replace("\n", " ")[:42]
        print(f"{r['content_id'][:24]:24} {('Y' if r['enabled'] else 'N'):3} {count:<5} {preview}")


def cmd_add_campaign(args):
    s = Settings.load(False); db = db_for(s)
    create_campaign(db, args.campaign_id, args.name, args.content_id, args.priority, args.tags or "",
                    start_at=args.start_at, end_at=args.end_at,
                    min_destination_interval_seconds=args.min_interval)
    print(f"[OK] Campaign saved (disabled by default on first creation): {args.campaign_id}")


def cmd_campaigns(args):
    s = Settings.load(False); db = db_for(s)
    with db.connect() as con:
        rows = con.execute('''SELECT c.*,s.mode AS schedule_mode,s.enabled AS schedule_enabled,s.next_run_at
                              FROM campaigns c LEFT JOIN campaign_schedules s ON s.campaign_id=c.campaign_id
                              ORDER BY c.priority DESC,c.campaign_id''').fetchall()
    if not rows:
        print("No campaigns."); return
    print(f"{'CAMPAIGN':18} {'ON':3} {'PRI':3} {'CONTENT':18} {'SCHEDULE':10} NEXT RUN")
    print("-" * 105)
    for r in rows:
        sched = r["schedule_mode"] if r["schedule_enabled"] else "manual"
        print(f"{r['campaign_id'][:18]:18} {('Y' if r['enabled'] else 'N'):3} {r['priority']:<3} {r['content_id'][:18]:18} {sched[:10]:10} {r['next_run_at'] or '-'}")


def cmd_campaign_toggle(args):
    s = Settings.load(False); db = db_for(s)
    with db.connect() as con:
        row = con.execute("SELECT campaign_id FROM campaigns WHERE campaign_id=?", (args.campaign_id,)).fetchone()
        if not row:
            raise RuntimeError(f"Unknown campaign: {args.campaign_id}")
        con.execute("UPDATE campaigns SET enabled=?,updated_at=? WHERE campaign_id=?", (1 if args.enabled else 0, utcnow(), args.campaign_id))
    print(f"[OK] Campaign {args.campaign_id}: {'enabled' if args.enabled else 'disabled'}")


def cmd_schedule(args):
    s = Settings.load(False); db = db_for(s)
    tz = args.timezone or s.timezone
    if args.off:
        disable_schedule(db, args.campaign_id)
        print(f"[OK] Schedule disabled: {args.campaign_id}")
        return
    if args.interval_minutes is not None:
        configure_interval(db, args.campaign_id, int(args.interval_minutes * 60), tz,
                           start_in_seconds=None if args.start_in_minutes is None else int(args.start_in_minutes * 60))
    else:
        times = [x.strip() for x in args.daily_times.split(",") if x.strip()]
        days = [x.strip() for x in (args.days or "").split(",") if x.strip()] or None
        configure_daily(db, args.campaign_id, times, days, tz)
    with db.connect() as con:
        r = con.execute("SELECT * FROM campaign_schedules WHERE campaign_id=?", (args.campaign_id,)).fetchone()
    print(f"[OK] {args.campaign_id} schedule={r['mode']} next_run={r['next_run_at']} timezone={r['timezone']}")


def cmd_scheduler(args):
    s = Settings.load(False); db = db_for(s)
    results = Scheduler(db).tick()
    if not results:
        print("[OK] No schedules due.")
    for r in results:
        print(json.dumps(r, indent=2))


def cmd_enqueue(args):
    s = Settings.load(False); db = db_for(s)
    problems = validate(db)
    if problems:
        print("[FAIL] Fix validation problems before enqueueing:")
        for x in problems: print(" -", x)
        raise SystemExit(2)
    r = enqueue_campaign(db, args.campaign_id, args.dry_run, run_key=args.run_key)
    print(json.dumps(r, indent=2))
    if args.dry_run:
        print("[DRY RUN] Nothing was added to the queue")


def _destination_tags(con, gid: int):
    return [x[0] for x in con.execute("SELECT tag FROM destination_tags WHERE group_id=? ORDER BY tag", (gid,)).fetchall()]


def cmd_destinations(args):
    s = Settings.load(False); db = db_for(s)
    where, params = [], []
    if args.review: where.append("needs_review=1")
    if args.enabled: where.append("enabled=1")
    if args.disabled: where.append("enabled=0")
    if args.search:
        where.append("(LOWER(group_name) LIKE ? OR CAST(group_id AS TEXT) LIKE ? OR LOWER(COALESCE(username,'')) LIKE ?)")
        q = f"%{args.search.lower()}%"; params += [q,q,q]
    sql = "SELECT * FROM destinations" + (" WHERE " + " AND ".join(where) if where else "") + " ORDER BY group_name LIMIT ?"
    params.append(args.limit)
    with db.connect() as con:
        rows = con.execute(sql, params).fetchall()
        print(f"{'ID':16} {'ON':3} {'REV':3} {'MODE':8} {'ACCT':9} {'P/S':3} NAME / TAGS")
        print("-" * 120)
        for r in rows:
            tags = ",".join(_destination_tags(con, r["group_id"]))
            access = f"{int(bool(r['primary_access']))}/{int(bool(r['secondary_access']))}"
            suffix = f" [{tags}]" if tags else ""
            print(f"{r['group_id']:<16} {('Y' if r['enabled'] else 'N'):3} {('Y' if r['needs_review'] else 'N'):3} {r['mode'][:8]:8} {r['preferred_account'][:9]:9} {access:3} {r['group_name']}{suffix}")


def cmd_destination(args):
    s = Settings.load(False); db = db_for(s)
    gid = int(args.group_id)
    with db.connect() as con:
        row = con.execute("SELECT * FROM destinations WHERE group_id=?", (gid,)).fetchone()
        if not row:
            raise RuntimeError(f"Unknown destination: {gid}")
        sets, vals = [], []
        if args.approve:
            sets += ["needs_review=0"]
        if args.mode is not None:
            sets += ["mode=?"]; vals += [args.mode]
        if args.account is not None:
            sets += ["preferred_account=?"]; vals += [args.account]
        if args.topic is not None:
            sets += ["topic_id=?"]; vals += [None if args.topic.lower() == "none" else int(args.topic)]
        if args.min_interval is not None:
            if args.min_interval < 0: raise ValueError("min interval cannot be negative")
            sets += ["min_interval_seconds=?"]; vals += [args.min_interval]
        if args.quiet_start is not None or args.quiet_end is not None:
            start = args.quiet_start if args.quiet_start is not None else row["quiet_start"]
            end = args.quiet_end if args.quiet_end is not None else row["quiet_end"]
            if (start is None) != (end is None):
                raise ValueError("quiet hours require both --quiet-start and --quiet-end")
            if start and end:
                parse_hhmm(start); parse_hhmm(end)
                if start == end: raise ValueError("quiet start/end cannot be identical")
            sets += ["quiet_start=?", "quiet_end=?"]; vals += [start,end]
        if args.clear_quiet:
            sets += ["quiet_start=NULL", "quiet_end=NULL"]
        if args.note is not None:
            sets += ["notes=?"]; vals += [args.note]
        if args.enable is True:
            effective_review = False if args.approve else bool(row["needs_review"])
            effective_mode = args.mode if args.mode is not None else row["mode"]
            if effective_review:
                raise RuntimeError("Destination still needs review. Use --approve before enabling.")
            if effective_mode not in {"photo","text"}:
                raise RuntimeError("Destination mode must be photo or text before enabling.")
            sets += ["enabled=1"]
        elif args.enable is False:
            sets += ["enabled=0"]
        if sets:
            sets += ["updated_at=?"]; vals += [utcnow(), gid]
            con.execute(f"UPDATE destinations SET {','.join(sets)} WHERE group_id=?", vals)
        for tag in args.add_tag or []:
            tag = tag.strip().lower()
            if tag: con.execute("INSERT OR IGNORE INTO destination_tags(group_id,tag) VALUES(?,?)", (gid,tag))
        for tag in args.remove_tag or []:
            con.execute("DELETE FROM destination_tags WHERE group_id=? AND tag=?", (gid,tag.strip().lower()))
        row = con.execute("SELECT * FROM destinations WHERE group_id=?", (gid,)).fetchone()
        tags = _destination_tags(con, gid)
    print(json.dumps({**dict(row), "tags": tags}, indent=2, default=str))


def cmd_queue(args):
    s = Settings.load(False); db = db_for(s)
    where, params = [], []
    if args.status:
        where.append("q.status=?"); params.append(args.status)
    if args.campaign:
        where.append("q.campaign_id=?"); params.append(args.campaign)
    sql = '''SELECT q.id,q.status,q.due_at,q.attempts,q.account_key,q.campaign_id,q.group_id,d.group_name,q.last_error
             FROM queue q JOIN destinations d ON d.group_id=q.group_id'''
    if where: sql += " WHERE " + " AND ".join(where)
    sql += " ORDER BY q.id DESC LIMIT ?"; params.append(args.limit)
    with db.connect() as con: rows = con.execute(sql, params).fetchall()
    if not rows: print("No matching queue jobs."); return
    print(f"{'ID':6} {'STATUS':10} {'ATT':3} {'ACCOUNT':9} {'CAMPAIGN':16} {'GROUP':16} NAME / ERROR")
    print("-"*120)
    for r in rows:
        tail = r["group_name"]
        if r["last_error"]: tail += " | " + r["last_error"][:55]
        print(f"{r['id']:<6} {r['status'][:10]:10} {r['attempts']:<3} {(r['account_key'] or '-')[:9]:9} {r['campaign_id'][:16]:16} {r['group_id']:<16} {tail}")


def cmd_job(args):
    s = Settings.load(False); db = db_for(s)
    with db.connect() as con:
        row = con.execute("SELECT * FROM queue WHERE id=?", (args.job_id,)).fetchone()
        if not row: raise RuntimeError(f"Unknown queue job: {args.job_id}")
        if args.retry:
            if row["status"] not in {"failed","uncertain","cancelled"}:
                raise RuntimeError(f"Job status {row['status']} is not eligible for explicit retry")
            con.execute("UPDATE queue SET status='retry',due_at=?,last_error='manual retry requested',updated_at=? WHERE id=?", (utcnow(),utcnow(),args.job_id))
            action="retry"
        elif args.cancel:
            if row["status"] == "sent": raise RuntimeError("Cannot cancel a sent job")
            con.execute("UPDATE queue SET status='cancelled',updated_at=? WHERE id=?", (utcnow(),args.job_id)); action="cancelled"
        elif args.mark_sent:
            if row["status"] not in {"uncertain","failed"}: raise RuntimeError("mark-sent is only for uncertain/failed jobs")
            con.execute("UPDATE queue SET status='sent',last_error='manually resolved as sent',updated_at=? WHERE id=?", (utcnow(),args.job_id)); action="marked sent"
        else:
            print(json.dumps(dict(row), indent=2)); return
    print(f"[OK] Job {args.job_id}: {action}")


def cmd_status(args):
    s = Settings.load(False); db = db_for(s)
    with db.connect() as con:
        print("\nSMART AUTO POSTER V2 STATUS")
        print("="*72)
        print(f"database              {db.path}")
        for status, n in con.execute("SELECT status,COUNT(*) FROM queue GROUP BY status ORDER BY status"):
            print(f"queue {status:15} {n}")
        print("destinations enabled  ", con.execute("SELECT COUNT(*) FROM destinations WHERE enabled=1").fetchone()[0])
        print("destinations review   ", con.execute("SELECT COUNT(*) FROM destinations WHERE needs_review=1").fetchone()[0])
        print("destinations quarantine", con.execute("SELECT COUNT(*) FROM destinations WHERE quarantine_until> ?", (utcnow(),)).fetchone()[0])
        print("campaigns enabled     ", con.execute("SELECT COUNT(*) FROM campaigns WHERE enabled=1").fetchone()[0])
        print("schedules enabled     ", con.execute("SELECT COUNT(*) FROM campaign_schedules WHERE enabled=1").fetchone()[0])
        print("content items         ", con.execute("SELECT COUNT(*) FROM content").fetchone()[0])
        accounts = con.execute("SELECT account_key,authorized,identity,cooldown_until,last_error FROM accounts ORDER BY account_key").fetchall()
        if accounts:
            print("\nACCOUNTS")
            for a in accounts:
                state = "AUTHORIZED" if a["authorized"] else "NOT AUTHORIZED"
                if a["cooldown_until"] and a["cooldown_until"] > utcnow(): state += f" | cooldown until {a['cooldown_until']}"
                print(f"{a['account_key']:10} {state} | {a['identity'] or '-'}")
        recent = con.execute("SELECT created_at,severity,event_type,message FROM events ORDER BY id DESC LIMIT 10").fetchall()
        if recent:
            print("\nRECENT EVENTS")
            for r in recent: print(f"{r['created_at']} {r['severity']:7} {r['event_type']:18} {r['message'][:86]}")


async def async_scan(args):
    try:
        from .telegram_io import TelegramPool
        from .worker import Worker
    except ImportError as exc:
        raise RuntimeError("Telegram dependencies are not installed. Run: py -m pip install -r requirements.txt") from exc
    s = Settings.load(True); s.ensure_dirs(); db = db_for(s)
    with RuntimeLock(s.runtime_lock_path):
        pool = TelegramPool(s.api_id,s.api_hash,s.sessions,s.staging_chats,s.media_cache_dir)
        await pool.connect()
        try:
            auth = await pool.authorization(); print(json.dumps(auth,indent=2))
            Worker(db,pool,timezone_name=s.timezone,min_send_gap_seconds=s.min_send_gap_seconds).sync_accounts(auth,s.sessions)
            with db.connect() as con:
                for key in ("primary","secondary"):
                    if not auth.get(key,{}).get("authorized"):
                        continue
                    # Authoritative refresh for this account: unseen destinations lose this access flag.
                    con.execute(f"UPDATE destinations SET {key}_access=0,updated_at=?", (utcnow(),))
                    dialogs = await pool.dialogs(key)
                    print(f"{key.upper()}: {len(dialogs)} destinations")
                    for x in dialogs:
                        existing = con.execute("SELECT * FROM destinations WHERE group_id=?", (x['group_id'],)).fetchone()
                        if existing:
                            con.execute(f"UPDATE destinations SET group_name=?,chat_type=?,username=?,forum=?,{key}_access=1,updated_at=? WHERE group_id=?",
                                        (x['group_name'],x['chat_type'],x['username'],int(x['forum']),utcnow(),x['group_id']))
                        else:
                            con.execute(f'''INSERT INTO destinations(group_id,group_name,chat_type,username,forum,{key}_access,preferred_account,mode,enabled,needs_review,updated_at)
                                            VALUES(?,?,?,?,?,1,?,'review',0,1,?)''',
                                        (x['group_id'],x['group_name'],x['chat_type'],x['username'],int(x['forum']),key,utcnow()))
                # If both sessions were successfully scanned and neither sees a destination anymore, fail closed.
                if all(auth.get(k,{}).get("authorized") for k in ("primary","secondary")):
                    con.execute("UPDATE destinations SET enabled=0,needs_review=1,notes=TRIM(COALESCE(notes,'') || ' access lost on scan'),updated_at=? WHERE primary_access=0 AND secondary_access=0 AND enabled=1", (utcnow(),))
            print("[OK] Scan synchronized. New destinations remain REVIEW + disabled. Lost access fails closed.")
        finally:
            await pool.disconnect()


def cmd_scan(args): asyncio.run(async_scan(args))


async def _telegram_runtime(args, mode: str):
    try:
        from .telegram_io import TelegramPool
        from .worker import Worker
        from .service import AutoPosterService
    except ImportError as exc:
        raise RuntimeError("Telegram dependencies are not installed. Run: py -m pip install -r requirements.txt") from exc
    s = Settings.load(True); s.ensure_dirs(); db = db_for(s)
    safety = _safety_controller(s, db)
    with RuntimeLock(s.runtime_lock_path):
        pool = TelegramPool(s.api_id,s.api_hash,s.sessions,s.staging_chats,s.media_cache_dir)
        await pool.connect()
        try:
            if mode == "worker":
                state = safety.status()
                if state.paused:
                    raise RuntimeError(f"Outbound posting is safety-paused: {state.reason or 'no reason'}")
                auth = await pool.authorization(); print("Authorization:", json.dumps(auth))
                w = Worker(db,pool,poll_seconds=args.poll,timezone_name=s.timezone,min_send_gap_seconds=s.min_send_gap_seconds,safety=safety)
                w.sync_accounts(auth,s.sessions)
                recovered = w.recover_interrupted_sends()
                if recovered: print(f"[RECOVERY] {recovered} interrupted send(s) marked UNCERTAIN")
                if args.once:
                    worked = await w.run_once(auth); print("[OK] one queue cycle", "processed" if worked else "idle")
                else:
                    print("[RUNNING] Queue worker active. Ctrl+C to stop cleanly.")
                    await w.run_forever(auth,s.sessions)
            else:
                service = AutoPosterService(db,pool,s,poll_seconds=args.poll,scheduler_seconds=args.scheduler_poll)
                await service.run()
        finally:
            await pool.disconnect()

def cmd_worker(args):
    try: asyncio.run(_telegram_runtime(args,"worker"))
    except KeyboardInterrupt: print("\n[STOPPED] Worker stopped")


def cmd_run(args):
    try: asyncio.run(_telegram_runtime(args,"service"))
    except KeyboardInterrupt: print("\n[STOPPED] Smart Auto Poster stopped cleanly")


def cmd_health(args):
    import sys
    try:
        from importlib.metadata import version as pkg_version
    except ImportError:
        pkg_version = None
    s = Settings.load(False); s.ensure_dirs(); db = db_for(s)
    checks = []
    checks.append(("Python", True, sys.version.split()[0]))
    try:
        tv = pkg_version("telethon") if pkg_version else "installed"
        checks.append(("Telethon", True, tv))
    except Exception:
        checks.append(("Telethon", False, "not installed - run setup"))
    checks.append(("API credentials", bool(s.api_id and s.api_hash), "configured" if (s.api_id and s.api_hash) else "missing in .env"))
    for key, session in s.sessions.items():
        pth = Path(session)
        if pth.suffix != ".session":
            pth = Path(str(pth) + ".session")
        checks.append((f"{key} session", pth.exists(), str(pth)))
    checks.append(("destination config", s.config_csv.exists(), str(s.config_csv)))
    checks.append(("database", s.database_path.exists(), str(s.database_path)))
    checks.append(("runtime lock", not s.runtime_lock_path.exists(), "clear" if not s.runtime_lock_path.exists() else f"present: {s.runtime_lock_path}"))
    safety_state = _safety_controller(s, db).status()
    checks.append(("outbound safety", not safety_state.paused, "ready" if not safety_state.paused else f"PAUSED: {safety_state.reason or '-'}"))
    problems = validate(db)
    checks.append(("local validation", not problems, "OK" if not problems else f"{len(problems)} problem(s)"))

    print("SMART AUTO POSTER V2 - HEALTH CHECK")
    print("="*72)
    for name, ok, detail in checks:
        print(f"{('[OK]' if ok else '[!!]'):4} {name:22} {detail}")
    if problems:
        print("\nVALIDATION DETAILS")
        for x in problems:
            print(" -", x)
    ready = all(ok for name,ok,_ in checks if name not in {"destination config", "runtime lock"})
    if ready:
        print("\n[READY] Local runtime prerequisites look ready for controlled live validation.")
    else:
        print("\n[NOT READY] Fix the items marked [!!] before unattended live operation.")


def _safety_controller(s, db):
    return SafetyController(
        db,
        failure_threshold=s.circuit_breaker_failures,
        window_minutes=s.circuit_breaker_window_minutes,
        pause_minutes=s.circuit_breaker_pause_minutes,
        failure_ratio=s.circuit_breaker_failure_ratio,
    )


def cmd_safety_status(args):
    s = Settings.load(False); db = db_for(s)
    state = _safety_controller(s, db).status()
    print("SMART AUTO POSTER - SAFETY STATUS")
    print("="*72)
    print(f"outbound paused       {'YES' if state.paused else 'NO'}")
    print(f"manual pause          {'YES' if state.manual else 'NO'}")
    print(f"pause until           {state.until or '-'}")
    print(f"reason                {state.reason or '-'}")
    print(f"recent successes      {state.successes}")
    print(f"recent failures       {state.failures}")
    print(f"breaker threshold     {s.circuit_breaker_failures} failures / {s.circuit_breaker_window_minutes} min")
    print(f"breaker ratio         {s.circuit_breaker_failure_ratio:.0%}")
    print(f"automatic pause       {s.circuit_breaker_pause_minutes} min")


def cmd_pause(args):
    s = Settings.load(False); db = db_for(s)
    controller = _safety_controller(s, db)
    state = controller.pause(args.reason or "manual outbound pause", args.minutes, manual=(args.minutes is None))
    print(f"[OK] Outbound posting paused. Reason: {state.reason}")
    print(f"Resume: {'manual command required' if state.manual else state.until}")


def cmd_resume(args):
    s = Settings.load(False); db = db_for(s)
    _safety_controller(s, db).resume("manual resume")
    print("[OK] Outbound posting resumed")


def cmd_backup(args):
    s = Settings.load(False); db = db_for(s)
    outputs = []
    stamp = utcnow().replace(":","").replace("+00:00","Z")
    db_dst = s.backup_dir / f"smart_autoposter_{stamp}.sqlite3"
    db.backup_to(db_dst); outputs.append(db_dst)
    cfg = _backup_file(s.config_csv,s.backup_dir,"destination_config")
    if cfg: outputs.append(cfg)
    cache = s.media_cache_dir
    if cache.exists():
        dst = s.backup_dir / f"media_cache_{stamp}"
        shutil.copytree(cache,dst,dirs_exist_ok=True); outputs.append(dst)
    print("[OK] Consistent backup complete")
    for x in outputs: print(" -",x)


def cmd_export(args):
    s = Settings.load(False); db = db_for(s)
    out = Path(args.output); out.parent.mkdir(parents=True,exist_ok=True)
    with db.connect() as con, out.open("w",newline="",encoding="utf-8-sig") as f:
        rows = con.execute("SELECT * FROM destinations ORDER BY group_name").fetchall()
        fields = list(rows[0].keys()) + ["tags"] if rows else ["group_id","group_name","tags"]
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader()
        for r in rows:
            d=dict(r); d["tags"] = ",".join(_destination_tags(con,r["group_id"])); w.writerow(d)
    print(f"[OK] Exported destinations: {out}")


def build_parser():
    p=argparse.ArgumentParser(prog="smart-autoposter",description="Smart Auto Poster V2")
    sp=p.add_subparsers(dest="cmd",required=True)

    a=sp.add_parser("init"); a.set_defaults(func=cmd_init)
    a=sp.add_parser("import-config"); a.add_argument("--csv"); a.set_defaults(func=cmd_import)
    a=sp.add_parser("validate"); a.set_defaults(func=cmd_validate)
    a=sp.add_parser("scan"); a.set_defaults(func=cmd_scan)

    a=sp.add_parser("add-content"); a.add_argument("content_id"); a.add_argument("--caption"); a.add_argument("--caption-file"); a.add_argument("--media",nargs="*"); a.set_defaults(func=cmd_add_content)
    a=sp.add_parser("contents"); a.set_defaults(func=cmd_contents)

    a=sp.add_parser("add-campaign"); a.add_argument("campaign_id"); a.add_argument("name"); a.add_argument("content_id"); a.add_argument("--priority",type=int,default=50); a.add_argument("--tags",default=""); a.add_argument("--start-at"); a.add_argument("--end-at"); a.add_argument("--min-interval",type=int,default=0); a.set_defaults(func=cmd_add_campaign)
    a=sp.add_parser("campaigns"); a.set_defaults(func=cmd_campaigns)
    a=sp.add_parser("campaign"); a.add_argument("campaign_id"); g=a.add_mutually_exclusive_group(required=True); g.add_argument("--enable",dest="enabled",action="store_true"); g.add_argument("--disable",dest="enabled",action="store_false"); a.set_defaults(func=cmd_campaign_toggle)

    a=sp.add_parser("schedule"); a.add_argument("campaign_id"); g=a.add_mutually_exclusive_group(required=True); g.add_argument("--interval-minutes",type=float); g.add_argument("--daily-times"); g.add_argument("--off",action="store_true"); a.add_argument("--days",help="comma-separated mon,tue,...; default all days"); a.add_argument("--timezone"); a.add_argument("--start-in-minutes",type=float); a.set_defaults(func=cmd_schedule)
    a=sp.add_parser("scheduler"); a.set_defaults(func=cmd_scheduler)

    a=sp.add_parser("enqueue"); a.add_argument("campaign_id"); a.add_argument("--dry-run",action="store_true"); a.add_argument("--run-key"); a.set_defaults(func=cmd_enqueue)

    a=sp.add_parser("destinations"); a.add_argument("--review",action="store_true"); a.add_argument("--enabled",action="store_true"); a.add_argument("--disabled",action="store_true"); a.add_argument("--search"); a.add_argument("--limit",type=int,default=100); a.set_defaults(func=cmd_destinations)
    a=sp.add_parser("destination"); a.add_argument("group_id"); a.add_argument("--approve",action="store_true"); a.add_argument("--mode",choices=["photo","text","review","disabled"]); a.add_argument("--account",choices=["primary","secondary","both"]); a.add_argument("--topic"); a.add_argument("--min-interval",type=int); a.add_argument("--quiet-start"); a.add_argument("--quiet-end"); a.add_argument("--clear-quiet",action="store_true"); a.add_argument("--add-tag",action="append"); a.add_argument("--remove-tag",action="append"); a.add_argument("--note"); eg=a.add_mutually_exclusive_group(); eg.add_argument("--enable",dest="enable",action="store_true"); eg.add_argument("--disable",dest="enable",action="store_false"); a.set_defaults(enable=None,func=cmd_destination)

    a=sp.add_parser("queue"); a.add_argument("--status",choices=["pending","retry","sending","sent","failed","uncertain","cancelled"]); a.add_argument("--campaign"); a.add_argument("--limit",type=int,default=50); a.set_defaults(func=cmd_queue)
    a=sp.add_parser("job"); a.add_argument("job_id",type=int); g=a.add_mutually_exclusive_group(); g.add_argument("--retry",action="store_true"); g.add_argument("--cancel",action="store_true"); g.add_argument("--mark-sent",action="store_true"); a.set_defaults(func=cmd_job)

    a=sp.add_parser("status"); a.set_defaults(func=cmd_status)
    a=sp.add_parser("health"); a.set_defaults(func=cmd_health)
    a=sp.add_parser("worker"); a.add_argument("--once",action="store_true"); a.add_argument("--poll",type=int,default=5); a.set_defaults(func=cmd_worker)
    a=sp.add_parser("run"); a.add_argument("--poll",type=int,default=5); a.add_argument("--scheduler-poll",type=int,default=15); a.set_defaults(func=cmd_run)
    a=sp.add_parser("safety-status"); a.set_defaults(func=cmd_safety_status)
    a=sp.add_parser("pause"); a.add_argument("--minutes",type=int); a.add_argument("--reason"); a.set_defaults(func=cmd_pause)
    a=sp.add_parser("resume"); a.set_defaults(func=cmd_resume)
    a=sp.add_parser("backup"); a.set_defaults(func=cmd_backup)
    a=sp.add_parser("export-destinations"); a.add_argument("--output",default="exports/destinations_latest.csv"); a.set_defaults(func=cmd_export)
    return p


def main():
    args=build_parser().parse_args()
    try:
        args.func(args)
    except (RuntimeError,ValueError,FileNotFoundError) as exc:
        print(f"[ERROR] {exc}")
        raise SystemExit(2)


if __name__ == "__main__": main()
