from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
try:
    from dotenv import load_dotenv
except ImportError:
    def load_dotenv(*args, **kwargs):
        return False

load_dotenv()


def _path(name: str, default: str) -> Path:
    return Path(os.getenv(name, default).strip())


@dataclass(frozen=True)
class Settings:
    api_id: int
    api_hash: str
    primary_session: str
    secondary_session: str
    database_path: Path
    config_csv: Path
    timezone: str
    primary_staging_chat_id: int | None
    secondary_staging_chat_id: int | None
    media_cache_dir: Path
    backup_dir: Path
    log_dir: Path
    min_send_gap_seconds: int
    runtime_lock_path: Path
    auth_refresh_seconds: int
    circuit_breaker_failures: int
    circuit_breaker_window_minutes: int
    circuit_breaker_pause_minutes: int
    circuit_breaker_failure_ratio: float
    auto_backup_hours: int
    auto_backup_keep: int

    @classmethod
    def load(cls, require_credentials: bool = False) -> "Settings":
        api_id_raw = os.getenv("TELEGRAM_API_ID", "").strip()
        api_hash = os.getenv("TELEGRAM_API_HASH", "").strip()
        if require_credentials and (not api_id_raw or not api_hash):
            raise RuntimeError("Missing TELEGRAM_API_ID / TELEGRAM_API_HASH in .env")
        api_id = int(api_id_raw) if api_id_raw else 0
        return cls(
            api_id=api_id,
            api_hash=api_hash,
            primary_session=os.getenv("PRIMARY_SESSION", "runtime/sessions/my_account").strip(),
            secondary_session=os.getenv("SECONDARY_SESSION", "runtime/sessions/Auto_Post_Secondary").strip(),
            database_path=_path("DATABASE_PATH", "data/smart_autoposter.sqlite3"),
            config_csv=_path("CONFIG_CSV", "config/telegram_recommended_config.csv"),
            timezone=os.getenv("DEFAULT_TIMEZONE", "Australia/Adelaide").strip(),
            primary_staging_chat_id=int(os.getenv("PRIMARY_STAGING_CHAT_ID")) if os.getenv("PRIMARY_STAGING_CHAT_ID", "").strip() else None,
            secondary_staging_chat_id=int(os.getenv("SECONDARY_STAGING_CHAT_ID")) if os.getenv("SECONDARY_STAGING_CHAT_ID", "").strip() else None,
            media_cache_dir=_path("MEDIA_CACHE_DIR", "data/cache"),
            backup_dir=_path("BACKUP_DIR", "backups"),
            log_dir=_path("LOG_DIR", "logs"),
            min_send_gap_seconds=max(0, int(os.getenv("MIN_SEND_GAP_SECONDS", "3"))),
            runtime_lock_path=_path("RUNTIME_LOCK_PATH", "runtime/telegram_runtime.lock"),
            auth_refresh_seconds=max(30, int(os.getenv("AUTH_REFRESH_SECONDS", "300"))),
            circuit_breaker_failures=max(1, int(os.getenv("CIRCUIT_BREAKER_FAILURES", "10"))),
            circuit_breaker_window_minutes=max(1, int(os.getenv("CIRCUIT_BREAKER_WINDOW_MINUTES", "10"))),
            circuit_breaker_pause_minutes=max(1, int(os.getenv("CIRCUIT_BREAKER_PAUSE_MINUTES", "30"))),
            circuit_breaker_failure_ratio=min(1.0, max(0.0, float(os.getenv("CIRCUIT_BREAKER_FAILURE_RATIO", "0.80")))),
            auto_backup_hours=max(0, int(os.getenv("AUTO_BACKUP_HOURS", "24"))),
            auto_backup_keep=max(1, int(os.getenv("AUTO_BACKUP_KEEP", "14"))),
        )

    @property
    def sessions(self) -> dict[str, str]:
        return {"primary": self.primary_session, "secondary": self.secondary_session}

    @property
    def staging_chats(self) -> dict[str, int | None]:
        return {"primary": self.primary_staging_chat_id, "secondary": self.secondary_staging_chat_id}

    def ensure_dirs(self):
        self.database_path.parent.mkdir(parents=True, exist_ok=True)
        self.config_csv.parent.mkdir(parents=True, exist_ok=True)
        Path(self.primary_session).parent.mkdir(parents=True, exist_ok=True)
        Path(self.secondary_session).parent.mkdir(parents=True, exist_ok=True)
        self.media_cache_dir.mkdir(parents=True, exist_ok=True)
        self.backup_dir.mkdir(parents=True, exist_ok=True)
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self.runtime_lock_path.parent.mkdir(parents=True, exist_ok=True)
