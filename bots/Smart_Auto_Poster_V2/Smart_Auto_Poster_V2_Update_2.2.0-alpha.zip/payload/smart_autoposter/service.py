from __future__ import annotations

import asyncio
import json
from datetime import datetime, timezone
from pathlib import Path

from .core import validate
from .scheduler import Scheduler
from .safety import SafetyController
from .worker import Worker


class AutoPosterService:
    """Runs scheduler + queue worker with self-health and safety controls."""

    def __init__(self, db, pool, settings, poll_seconds=5, scheduler_seconds=15):
        self.db = db
        self.pool = pool
        self.settings = settings
        self.poll_seconds = max(1, int(poll_seconds))
        self.scheduler_seconds = max(5, int(scheduler_seconds))
        self.safety = SafetyController(
            db,
            failure_threshold=settings.circuit_breaker_failures,
            window_minutes=settings.circuit_breaker_window_minutes,
            pause_minutes=settings.circuit_breaker_pause_minutes,
            failure_ratio=settings.circuit_breaker_failure_ratio,
        )
        self.worker = Worker(
            db,
            pool,
            poll_seconds=self.poll_seconds,
            timezone_name=settings.timezone,
            min_send_gap_seconds=settings.min_send_gap_seconds,
            safety=self.safety,
        )
        self.scheduler = Scheduler(db)
        self.stop_requested = False

    def _auto_backup(self):
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        dst = self.settings.backup_dir / f"smart_autoposter_auto_{stamp}.sqlite3"
        self.db.backup_to(dst)
        self.db.event("INFO", "auto_backup", f"Automatic database backup created: {dst.name}")

        keep = max(1, int(self.settings.auto_backup_keep))
        backups = sorted(
            self.settings.backup_dir.glob("smart_autoposter_auto_*.sqlite3"),
            key=lambda p: p.stat().st_mtime,
            reverse=True,
        )
        for old in backups[keep:]:
            try:
                old.unlink()
            except OSError:
                pass
        return dst

    async def _refresh_auth(self, previous: dict) -> dict:
        try:
            current = await self.pool.authorization()
            self.worker.sync_accounts(current, self.settings.sessions)
            if current != previous:
                self.db.event("INFO", "authorization_refresh", "Telegram account authorization state refreshed", details=json.dumps(current))
                print("[HEALTH] Authorization refreshed:", json.dumps(current))
            return current
        except Exception as exc:
            self.db.event("WARNING", "authorization_refresh_failed", str(exc)[:800])
            print(f"[WARNING] Authorization refresh failed: {exc}")
            return previous

    async def run(self):
        problems = validate(self.db)
        if problems:
            raise RuntimeError("Pre-flight validation failed:\n - " + "\n - ".join(problems))

        auth = await self.pool.authorization()
        print("Authorization:", json.dumps(auth))
        self.worker.sync_accounts(auth, self.settings.sessions)
        recovered = self.worker.recover_interrupted_sends()
        if recovered:
            print(f"[RECOVERY] {recovered} interrupted send(s) marked UNCERTAIN")
        if not any(x.get("authorized") for x in auth.values()):
            raise RuntimeError("No authorized Telegram user sessions")

        print("[RUNNING] Smart Auto Poster service active (scheduler + queue worker + safety). Ctrl+C to stop.")
        loop = asyncio.get_running_loop()
        last_schedule = 0.0
        last_safety = 0.0
        last_auth_refresh = loop.time()
        last_backup = loop.time()
        last_pause_message = 0.0
        safety_interval = 10.0

        while not self.stop_requested:
            now = loop.time()

            if now - last_schedule >= self.scheduler_seconds:
                results = self.scheduler.tick()
                for result in results:
                    print(f"[SCHEDULE] {result['campaign_id']}: inserted={result['inserted']} duplicates={result['duplicates']}")
                last_schedule = now

            if now - last_safety >= safety_interval:
                state = self.safety.evaluate()
                last_safety = now
            else:
                state = self.safety.status()

            if now - last_auth_refresh >= self.settings.auth_refresh_seconds:
                auth = await self._refresh_auth(auth)
                last_auth_refresh = now

            if self.settings.auto_backup_hours > 0 and now - last_backup >= self.settings.auto_backup_hours * 3600:
                try:
                    dst = self._auto_backup()
                    print(f"[BACKUP] {dst}")
                except Exception as exc:
                    self.db.event("WARNING", "auto_backup_failed", str(exc)[:800])
                    print(f"[WARNING] Automatic backup failed: {exc}")
                last_backup = now

            if state.paused:
                if now - last_pause_message >= 60:
                    until = state.until or "manual resume"
                    print(f"[SAFETY PAUSED] {state.reason or 'outbound paused'} | until: {until}")
                    last_pause_message = now
                await asyncio.sleep(self.poll_seconds)
                continue

            worked = await self.worker.run_once(auth)
            if not worked:
                await asyncio.sleep(self.poll_seconds)
