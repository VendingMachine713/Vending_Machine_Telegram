# Self-test

Run from the Smart Auto Poster bot folder:

```powershell
py -m unittest discover -s tests -v
```

Current V2.2 local suite contains **16 tests** covering:

- schema creation/migration
- pre-flight validation
- queue duplicate protection
- recurring scheduler behaviour
- daily scheduling
- overnight quiet hours
- account selection/failover
- account pacing/cooldown logic
- consistent SQLite online backup
- manual outbound pause/resume
- automatic circuit-breaker trigger logic
- circuit-breaker false-trigger resistance
- duplicate Telegram-runtime prevention
- stale runtime-lock recovery

These tests do **not** connect to Telegram or send messages. Live Telegram validation must be done with the authorised sessions on the user's machine.
