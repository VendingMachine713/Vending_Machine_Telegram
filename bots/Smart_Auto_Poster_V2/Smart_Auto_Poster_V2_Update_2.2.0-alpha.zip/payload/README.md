# Smart Auto Poster V2

Smart Auto Poster V2 is the active publishing engine for the Vending Machine Telegram project. It is built around persistent state, fail-closed destination review, rate-aware sending, crash recovery, recurring schedules and a simple Windows control panel.

## Recommended way to use it

On Windows, open:

```text
CONTROL_PANEL.ps1
```

That provides shortcuts for status, validation, Telegram scanning, destination review, campaigns, queue inspection, one-job testing, backups, self-tests and the full scheduler+worker service.

## Bot-local folder layout

```text
Smart_Auto_Poster_V2/
├── app.py
├── CONTROL_PANEL.ps1
├── START_AUTO_POSTER.ps1
├── run_setup.ps1
├── .env
├── config/                 destination CSV/config
├── content/                post media/captions
├── data/
│   ├── smart_autoposter.sqlite3
│   └── cache/              Telegram media-cache state
├── runtime/
│   └── sessions/           this bot's Telethon session databases
├── exports/
├── backups/
├── logs/
├── tests/
└── smart_autoposter/       Python application modules
```

Live `.session` files stay bot-local rather than being shared between independent processes. This avoids multiple bots trying to write the same Telethon SQLite session database at the same time.

## Implemented V2 features

### Publishing core
- Primary + Secondary user-session support
- Destination registry backed by SQLite WAL
- Existing `telegram_recommended_config.csv` import
- New Telegram destinations default to `review` + disabled
- Authoritative access refresh during successful scans
- Lost access fails closed when both authorised sessions have been scanned
- Destination modes: `photo`, `text`, `review`, `disabled`
- Destination tags and campaign tag targeting
- Preferred account per destination
- Forum `topic_id` routing
- Per-destination minimum interval
- Campaign-wide destination spacing
- Destination quiet hours
- Reusable content library
- Photo/album + text sending
- Campaign priorities
- Start/end campaign fields

### Automation
- Persistent queue
- Duplicate protection per campaign + destination + run
- Manual run keys
- Interval schedules
- Daily time schedules
- Day-of-week schedules
- Adelaide timezone by default
- Missed schedule slots collapse to the next future slot instead of generating a catch-up burst
- One command runs scheduler + worker together:

```powershell
py .\app.py run
```

### Reliability / safety
- Local pre-flight validation
- Dry-run enqueue
- One-job controlled worker mode
- Crash recovery: in-flight sends become `uncertain`, never blindly retried
- Explicit resolution/retry for uncertain jobs
- FloodWait deferred retry and account cooldown
- Configurable per-account send pacing (`MIN_SEND_GAP_SECONDS`, default 3 seconds)
- SlowMode deferred retry at the destination level
- Network/WorkerBusy backoff without incorrectly penalising the destination
- Destination quarantine after repeated destination-specific failures
- Persistent event history
- Database schema migration from earlier V2 builds
- Consistent SQLite online backups (WAL-safe), config/cache backups
- Automatic database backups with retention during unattended service operation
- Single-instance Telegram runtime lock to prevent session/queue conflicts
- Persistent manual pause/resume safety state
- Automatic recent-failure circuit breaker
- Periodic account authorization health refresh
- API credentials excluded from source code
- Persistent Telegram media caching via private staging chat when configured

## First setup

From the bot folder:

```powershell
.\run_setup.ps1
```

The setup script creates the clean folder structure, installs dependencies, creates `.env` if needed, runs database migrations and executes the local test suite. If legacy V2 files exist in the bot root, it copies them into their new organised locations without overwriting existing files.

Edit `.env` locally and enter your Telegram API credentials. Do not send API hashes or session files through chat.

Then place/copy your live files into:

```text
runtime\sessions\my_account.session
runtime\sessions\Auto_Post_Secondary.session
config\telegram_recommended_config.csv
```

## Safe first live boot

```powershell
py .\app.py init
py .\app.py import-config
py .\app.py validate
py .\app.py scan
py .\app.py status
py .\app.py health
```

`scan` connects to Telegram but does not send posts. New destinations stay disabled until reviewed.

Review destinations:

```powershell
py .\app.py destinations --review
py .\app.py destination -100123456789 --approve --mode photo --account primary --enable
```

Optional destination rules:

```powershell
py .\app.py destination -100123456789 --min-interval 21600
py .\app.py destination -100123456789 --quiet-start 23:00 --quiet-end 07:00
py .\app.py destination -100123456789 --add-tag main --add-tag wholesale
```

## Content + campaign example

Put media in `content\campaign_a\` and a UTF-8 caption in `content\campaign_a\caption.txt`.

```powershell
py .\app.py add-content AD_A --caption-file .\content\campaign_a\caption.txt --media .\content\campaign_a\01.jpg .\content\campaign_a\02.jpg
py .\app.py add-campaign CAMP_A "Main Campaign" AD_A --priority 50 --tags main
py .\app.py campaign CAMP_A --enable
py .\app.py enqueue CAMP_A --dry-run
```

For a single controlled send:

```powershell
py .\app.py enqueue CAMP_A --run-key first-live-test
py .\app.py worker --once
py .\app.py status
```

Only after that succeeds should the continuous service be started.

## Recurring scheduling

Every six hours:

```powershell
py .\app.py schedule CAMP_A --interval-minutes 360
```

Every day at 09:00 and 19:00 Adelaide time:

```powershell
py .\app.py schedule CAMP_A --daily-times 09:00,19:00
```

Monday/Wednesday/Friday only:

```powershell
py .\app.py schedule CAMP_A --daily-times 10:00,18:30 --days mon,wed,fri
```

Disable a schedule:

```powershell
py .\app.py schedule CAMP_A --off
```

Run everything:

```powershell
py .\app.py run
```

## Queue recovery

List uncertain jobs:

```powershell
py .\app.py queue --status uncertain
```

After manually verifying whether Telegram received the post:

```powershell
py .\app.py job 123 --mark-sent
```

or explicitly retry it:

```powershell
py .\app.py job 123 --retry
```

This is intentionally manual because an interrupted process cannot reliably know whether Telegram accepted the message immediately before the local crash.

## Safety controls

Check the current outbound safety state:

```powershell
py .\app.py safety-status
```

Pause all outbound posting without destroying campaigns or queue state:

```powershell
py .\app.py pause --reason "maintenance"
```

Optionally pause for a fixed period:

```powershell
py .\app.py pause --minutes 30 --reason "temporary maintenance"
```

Resume manually:

```powershell
py .\app.py resume
```

The automatic circuit breaker defaults to pausing outbound sending for 30 minutes when at least 10 send attempts occur within the recent 10-minute window and 80% or more of those attempts fail. The scheduler can continue preserving future work in the persistent queue while sending is paused. These thresholds are configurable in `.env`.

The long-running service also refreshes Telegram account authorization state every five minutes by default and creates a consistent SQLite backup every 24 hours, retaining the latest 14 automatic database backups.

Only one Telegram-connected Smart Auto Poster process (`scan`, `worker`, or `run`) may use this bot's sessions at a time. The runtime lock prevents accidental concurrent launches.

## Backups and exports

```powershell
py .\app.py backup
py .\app.py export-destinations
```

## Local tests

```powershell
py -m unittest discover -s tests -v
```

These tests do not connect to Telegram or send anything.

## Operating rule

For any new or materially changed campaign:

1. `validate`
2. `enqueue ... --dry-run`
3. enqueue a deliberately named test run
4. `worker --once`
5. confirm the result
6. only then enable unattended `run`

The project deliberately respects Telegram flood/slow-mode restrictions instead of attempting to evade them.
