# Changelog

## 2.2.0-alpha — 2026-08-27

- Added single-instance Telegram runtime lock to prevent accidentally running two scanners/workers/services against the same bot-local Telethon sessions.
- Added stale runtime-lock recovery when the recorded process no longer exists.
- Added outbound safety controller with manual pause/resume state stored persistently in SQLite.
- Added automatic circuit breaker based on recent send-failure count and failure ratio.
- Added `safety-status`, `pause`, and `resume` CLI commands plus Control Panel entries.
- Added periodic Telegram account authorization refresh in the long-running service.
- Added automatic online SQLite database backups with retention controls for unattended operation.
- Replaced raw SQLite file-copy backups with SQLite's online backup API so WAL-resident state is included consistently.
- Added runtime-lock and outbound-safety checks to the health report.
- Added event index for efficient recent safety-window queries; schema version is now 3.
- Expanded local test suite to 16 tests covering the new safety, backup, and runtime-lock behaviour.

## 2.1.0-alpha — 2026-08-27

- Added organised bot-local `config`, `data`, `runtime/sessions`, `exports`, `backups`, `logs` and `tests` folders.
- Added additive SQLite schema migration to schema v2.
- Added interval and daily/day-of-week recurring schedules.
- Added combined scheduler + queue `run` service.
- Reworked queue idempotency so each scheduled run has a deterministic `run_key`.
- Added destination quiet-hours enforcement.
- Added persistent account state and FloodWait cooldown enforcement.
- Added configurable per-account send pacing (3-second default) with non-blocking queue deferral.
- Kept SlowMode destination-specific rather than cooling down an entire account.
- Added authoritative account access refresh during Telegram scans.
- Added fail-closed lost-access handling when both accounts were successfully scanned.
- Added destination management, tags, review approval, account preference, topic ID, spacing and notes CLI.
- Added campaign/content/queue list views.
- Added explicit uncertain-job resolution (`--retry`, `--mark-sent`, `--cancel`).
- Added backup and destination export commands.
- Added Windows control panel.
- Added ten local automated tests plus a full CLI integration pass.
