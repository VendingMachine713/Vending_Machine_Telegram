$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location -LiteralPath $Root

function Pause-VM { Write-Host ''; Read-Host 'Press Enter to continue' | Out-Null }
function Run-Cmd([string]$Command) {
    Write-Host ''
    Write-Host "> $Command" -ForegroundColor DarkGray
    Invoke-Expression $Command
    Pause-VM
}

while ($true) {
    Clear-Host
    Write-Host '============================================================' -ForegroundColor Cyan
    Write-Host ' SMART AUTO POSTER V2 - CONTROL PANEL' -ForegroundColor Cyan
    Write-Host '============================================================' -ForegroundColor Cyan
    Write-Host ''
    Write-Host ' 1. Status'
    Write-Host ' 2. Health / readiness check'
    Write-Host ' 3. Validate database/config'
    Write-Host ' 4. Scan Telegram destinations'
    Write-Host ' 5. Show destinations needing review'
    Write-Host ' 6. Show enabled destinations'
    Write-Host ' 7. Show campaigns'
    Write-Host ' 8. Show queue'
    Write-Host ' 9. Run one queue job (controlled test)'
    Write-Host '10. START Smart Auto Poster service'
    Write-Host '11. Backup database/config/cache'
    Write-Host '12. Export destinations CSV'
    Write-Host '13. Run local self-tests'
    Write-Host '14. Open content folder'
    Write-Host '15. Open bot folder'
    Write-Host '16. Setup / upgrade environment'
    Write-Host '17. Import existing destination config'
    Write-Host '18. Safety status'
    Write-Host '19. PAUSE outbound posting'
    Write-Host '20. RESUME outbound posting'
    Write-Host ' 0. Exit'
    Write-Host ''
    $choice = Read-Host 'Choose'
    switch ($choice) {
        '1'  { Run-Cmd 'py .\app.py status' }
        '2'  { Run-Cmd 'py .\app.py health' }
        '3'  { Run-Cmd 'py .\app.py validate' }
        '4'  { Run-Cmd 'py .\app.py scan' }
        '5'  { Run-Cmd 'py .\app.py destinations --review' }
        '6'  { Run-Cmd 'py .\app.py destinations --enabled' }
        '7'  { Run-Cmd 'py .\app.py campaigns' }
        '8'  { Run-Cmd 'py .\app.py queue --limit 50' }
        '9'  { Run-Cmd 'py .\app.py worker --once' }
        '10' {
            Write-Host ''
            Write-Host 'Starting scheduler + worker. Use Ctrl+C to stop cleanly.' -ForegroundColor Yellow
            py .\app.py run
            Pause-VM
        }
        '11' { Run-Cmd 'py .\app.py backup' }
        '12' { Run-Cmd 'py .\app.py export-destinations' }
        '13' { Run-Cmd 'py -m unittest discover -s tests -v' }
        '14' { Start-Process explorer.exe (Join-Path $Root 'content') }
        '15' { Start-Process explorer.exe $Root }
        '16' { & (Join-Path $Root 'run_setup.ps1'); Pause-VM }
        '17' { Run-Cmd 'py .\app.py import-config' }
        '18' { Run-Cmd 'py .\app.py safety-status' }
        '19' { Run-Cmd 'py .\app.py pause --reason "control panel manual pause"' }
        '20' { Run-Cmd 'py .\app.py resume' }
        '0'  { return }
        default { Start-Sleep -Seconds 1 }
    }
}
